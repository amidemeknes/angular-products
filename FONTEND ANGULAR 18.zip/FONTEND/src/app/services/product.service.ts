import { Injectable } from '@angular/core';
import {ProductModel} from "../models/product.model";
import {CategoryModel} from "../models/category.model";

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  categories : CategoryModel[];
  product! : ProductModel;
  products : ProductModel[];
  constructor() {
    this.categories = [
      {idCategory : 1, category : "Bakery"},
      {idCategory : 2, category : "Dairy"},
      {idCategory : 3, category : "Meat"},
      {idCategory : 4, category : "Seafood"},
      {idCategory : 5, category : "Frozen food"},
      {idCategory : 6, category : "Fruit"},
    ];
    this.products = [
      {idProduct : 1, nameProduct : "Cheese", priceProduct : 37.00,
        category : {idCategory : 2, category : "Dairy"}, dateCreate : new Date()},
      {idProduct : 2, nameProduct : "Bread", priceProduct : 2.00,
        category : {idCategory : 1, category : "Bakery"}, dateCreate : new Date()},
      {idProduct : 3, nameProduct : "Milk", priceProduct : 10.00,
        category : {idCategory : 2, category : "Dairy"}, dateCreate : new Date()},
    ];
  }
  editCategory(id : number){
    return this.categories.find(c => c.idCategory == id)!;
  }
  categoriesList(){
    return this.categories;
  }
  productList(){
    return this.products;
  }
  addProduct(prod : ProductModel){
    this.products.push(prod);
  }
  deleteProduct(prod : ProductModel){
    const index = this.products.indexOf(prod, 0);
    this.products.splice(index, 1);
  }
  editProduct(id : number){
    this.product = this.products.find(p => p.idProduct == id)!;
    return this.product;
  }
  updateProduct(prod : ProductModel){
    this.deleteProduct(prod);
    this.addProduct(prod);
    this.sortProducts();
  }
  sortProducts(){
    this.products.sort((a,b)=>
      a.idProduct! - b.idProduct!
    )
  }
}
