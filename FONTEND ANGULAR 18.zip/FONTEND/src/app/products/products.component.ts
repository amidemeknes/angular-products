import {Component} from '@angular/core';
import {DatePipe, NgForOf} from "@angular/common";
import {ProductModel} from "../models/product.model";
import {ProductService} from "../services/product.service";
import {RouterLink} from "@angular/router";

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [
    NgForOf,
    DatePipe,
    RouterLink,
  ],
  templateUrl: './products.component.html',
  styleUrl: './products.component.css'
})
export class ProductsComponent{
  products! : ProductModel[];
  constructor(private productService : ProductService) {
      this.products = productService.productList();
  }
  deleteProduct(product : ProductModel){
    let conf = confirm("Are you sure to delete this product ?")
    if(conf)
      this.productService.deleteProduct(product);
  }
}
