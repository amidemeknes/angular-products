import {CategoryModel} from "./category.model";

export class ProductModel{
  idProduct? : number;
  nameProduct? : string;
  priceProduct? : number;
  category? : CategoryModel;
  dateCreate? : Date;
}
