export class CategoryModel{
  idCategory? : number;
  category? : string;
}
