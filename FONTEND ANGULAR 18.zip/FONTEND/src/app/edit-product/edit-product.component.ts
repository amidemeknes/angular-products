import {Component, OnInit} from '@angular/core';
import {ProductModel} from "../models/product.model";
import {FormsModule} from "@angular/forms";
import {ActivatedRoute, Router} from "@angular/router";
import {ProductService} from "../services/product.service";
import {DatePipe} from "@angular/common";
import {CategoryModel} from "../models/category.model";

@Component({
  selector: 'app-edit-product',
  standalone: true,
  imports: [
    FormsModule,
    DatePipe
  ],
  templateUrl: './edit-product.component.html',
  styleUrl: './edit-product.component.css'
})
export class EditProductComponent implements OnInit{
  categories : CategoryModel[];
  currentCategoryId! : number;
  currentProduct = new ProductModel();

  constructor(private activatedRoute : ActivatedRoute,
              private productService : ProductService,
              private router : Router
              ) {
    this.categories = productService.categoriesList();
  }

  ngOnInit(): void {
    //console.log(this.activatedRoute.snapshot.params['id']);
    this.currentProduct = this.productService.editProduct(this.activatedRoute.snapshot.params['id']);
    this.currentCategoryId = this.currentProduct.category?.idCategory!;
  }
  updateProduct(){
    this.currentProduct.category = this.productService.editCategory(this.currentCategoryId);
    this.productService.updateProduct(this.currentProduct);
    this.router.navigate(['products']);
  }
}
