import { Component } from '@angular/core';
import {ProductModel} from "../models/product.model";
import {FormsModule} from "@angular/forms";
import {ProductService} from "../services/product.service";
import {Router} from "@angular/router";
import {CategoryModel} from "../models/category.model";
import {NgForOf} from "@angular/common";

@Component({
  selector: 'app-add-product',
  standalone: true,
  imports: [
    FormsModule,
    NgForOf
  ],
  templateUrl: './add-product.component.html',
  styleUrl: './add-product.component.css'
})
export class AddProductComponent {
  categories : CategoryModel[];
  newCategoryId! : number;
  newProduct = new ProductModel();

  constructor(private productService : ProductService,
              private router : Router
              ) {
    this.categories = productService.categoriesList();
  }
  addProduct(){
    this.newProduct.category = this.productService.editCategory(this.newCategoryId);
    this.productService.addProduct(this.newProduct);
    this.router.navigate(['products']);
  }
}
